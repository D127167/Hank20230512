﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HankteamMVC.Models
{
    public class IndexModel
    {

    }
}